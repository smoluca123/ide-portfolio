"use client"

import { useState, useEffect, useRef } from "react"
import { ThemeProvider } from "./theme-context"
import { TitleBar } from "./title-bar"
import { ActivityBar } from "./activity-bar"
import { FileExplorer } from "./file-explorer"
import { EditorTabs } from "./editor-tabs"
import { Breadcrumbs } from "./breadcrumbs"
import { ExperienceContent } from "./experience-content"
import { HomeContent } from "./home-content"
import { AboutContent } from "./about-content"
import { ProjectsContent } from "./projects-content"
import { SkillsContent } from "./skills-content"
import { ContactContent } from "./contact-content"
import { ReadmeContent } from "./readme-content"
import { AICopilot } from "./ai-copilot"
import { StatusBar } from "./status-bar"
import { Terminal } from "./terminal"
import { CommandPalette } from "./command-palette"
import { SourceControl } from "./source-control"
import { Popover, PopoverContent } from "@/components/ui/popover"

export function IDELayout() {
  const [activeTab, setActiveTab] = useState("explorer")
  const [activeFile, setActiveFile] = useState("home.tsx")
  const [showCopilot, setShowCopilot] = useState(true)
  const [showTerminal, setShowTerminal] = useState(true)
  const [isTerminalMinimized, setIsTerminalMinimized] = useState(false)
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false)
  const [sourceControlOpen, setSourceControlOpen] = useState(false)
  const gitButtonRef = useRef<HTMLButtonElement>(null)

  // Handle Ctrl+P to open command palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "p") {
        e.preventDefault()
        setCommandPaletteOpen(true)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [])

  const handleActivityChange = (tab: string) => {
    if (tab === "ai") {
      setShowCopilot((prev) => !prev)
    } else if (tab === "terminal") {
      setShowTerminal((prev) => !prev)
      setIsTerminalMinimized(false)
    } else if (tab === "git") {
      // Git button is now a Popover trigger, don't need to handle here
      return
    }
    setActiveTab(tab)
  }

  return (
    <ThemeProvider>
    <div className="flex h-screen flex-col overflow-hidden bg-background">
      {/* Command Palette */}
      <CommandPalette
        isOpen={commandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        onFileSelect={setActiveFile}
        onCommand={(id) => {
          if (id === "open-copilot") {
            setShowCopilot(true)
            setActiveTab("ai")
          }
        }}
      />

      {/* Title bar */}
      <TitleBar onCommandPaletteOpen={() => setCommandPaletteOpen(true)} />

      {/* Body */}
      <div className="flex flex-1 overflow-hidden">
        {/* Activity bar */}
        <ActivityBar 
          activeTab={activeTab} 
          onTabChange={handleActivityChange}
          onCommandPaletteOpen={() => setCommandPaletteOpen(true)}
          gitButtonRef={gitButtonRef}
          sourceControlOpen={sourceControlOpen}
          onSourceControlOpenChange={setSourceControlOpen}
        />

        {/* File explorer - hidden on small screens */}
        <div className="hidden md:flex">
          <FileExplorer activeFile={activeFile} onFileSelect={setActiveFile} />
        </div>

        {/* Main area: Editor + Terminal */}
        <div className="flex flex-1 flex-col overflow-hidden">
          {/* Editor area */}
          <div className="flex flex-1 flex-col overflow-hidden">
            <EditorTabs activeTab={activeFile} onTabChange={setActiveFile} />
            <Breadcrumbs path={["aahana-bobade", "src", activeFile]} />
            {activeFile === "home.tsx" && <HomeContent />}
            {activeFile === "experience.ts" && <ExperienceContent />}
            {activeFile === "about.html" && <AboutContent />}
            {activeFile === "projects.js" && <ProjectsContent />}
            {activeFile === "skills.json" && <SkillsContent />}
            {activeFile === "contact.css" && <ContactContent />}
            {activeFile === "README.md" && <ReadmeContent />}
          </div>

          {/* Terminal Panel */}
          {showTerminal && !isTerminalMinimized && (
            <Terminal
              onClose={() => setShowTerminal(false)}
              isMinimized={isTerminalMinimized}
              onToggleMinimize={() => setIsTerminalMinimized((prev) => !prev)}
            />
          )}
        </div>

        {/* AI Copilot - hidden on small screens */}
        {showCopilot && (
          <div className="hidden lg:flex">
            <AICopilot onClose={() => setShowCopilot(false)} />
          </div>
        )}
      </div>

      {/* Status bar */}
      <StatusBar />
    </div>
    </ThemeProvider>
  )
}
