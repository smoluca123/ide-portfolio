"use client"

import { X } from "lucide-react"
import { cn } from "@/lib/utils"
import { useState } from "react"
import { useTheme } from "./theme-context"

interface Tab {
  name: string
  ext: "tsx" | "html" | "js" | "json" | "ts" | "css" | "md"
}

interface EditorTabsProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

const initialTabs: Tab[] = [
  { name: "home.tsx",       ext: "tsx"  },
  { name: "about.html",     ext: "html" },
  { name: "projects.js",    ext: "js"   },
  { name: "skills.json",    ext: "json" },
  { name: "experience.ts",  ext: "ts"   },
  { name: "contact.css",    ext: "css"  },
  { name: "README.md",      ext: "md"   },
]

const EXT_COLOR: Record<Tab["ext"], string> = {
  tsx:  "#5EC8FF",
  ts:   "#2DA8FF",
  js:   "#F7DF1E",
  json: "#FFBD2E",
  html: "#FF6B6B",
  css:  "#569CD6",
  md:   "#519ABA",
  html: "#F97316",
}

function TabFileIcon({ ext }: { ext: Tab["ext"] }) {
  const color = EXT_COLOR[ext]
  return (
    <span
      className="flex h-[14px] w-[20px] shrink-0 items-center justify-center rounded-sm font-mono text-[7px] font-bold"
      style={{ color, border: `1px solid ${color}44`, background: `${color}18` }}
    >
      {ext.toUpperCase().slice(0, 2)}
    </span>
  )
}

export function EditorTabs({ activeTab, onTabChange }: EditorTabsProps) {
  const [tabs, setTabs] = useState<Tab[]>(initialTabs)
  const { theme } = useTheme()

  const themeColors = {
    bg: theme === "dracula" ? "#282a36" : "#1A1A1A",
    border: theme === "dracula" ? "#44475a" : "#374151",
    text: theme === "dracula" ? "#f8f8f2" : "#CCCCCC",
    textMuted: theme === "dracula" ? "#6272a490" : "#CCCCCC/70",
    activeBg: theme === "dracula" ? "#3f4148" : "#1E1E1E",
    inactiveBg: theme === "dracula" ? "#282a36" : "#1A1A1A",
    activeAccent: theme === "dracula" ? "#50fa7b" : "#2DA8FF",
    hoverBg: theme === "dracula" ? "#3f414860" : "#1E1E1E/60",
  }

  const closeTab = (e: React.MouseEvent, name: string) => {
    e.stopPropagation()
    setTabs((prev) => prev.filter((t) => t.name !== name))
  }

  return (
    <div
      className="flex h-9 shrink-0 items-stretch overflow-x-auto border-b"
      style={{ 
        background: themeColors.bg,
        borderColor: themeColors.border,
      }}
    >
      {tabs.map((tab) => {
        const isActive = activeTab === tab.name
        return (
          <div
            key={tab.name}
            onClick={() => onTabChange(tab.name)}
            className={cn(
              "group relative flex cursor-pointer items-center gap-1.5 border-r px-3 transition-colors"
            )}
            style={{
              borderColor: themeColors.border,
              backgroundColor: isActive ? themeColors.activeBg : themeColors.inactiveBg,
              color: isActive ? themeColors.text : themeColors.textMuted,
            }}
            onMouseEnter={(e) => {
              if (!isActive) {
                e.currentTarget.style.backgroundColor = themeColors.hoverBg
                e.currentTarget.style.color = themeColors.text
              }
            }}
            onMouseLeave={(e) => {
              if (!isActive) {
                e.currentTarget.style.backgroundColor = themeColors.inactiveBg
                e.currentTarget.style.color = themeColors.textMuted
              }
            }}
          >
            {/* Active top border accent */}
            {isActive && (
              <span 
                className="absolute inset-x-0 top-0 h-[2px]"
                style={{ backgroundColor: themeColors.activeAccent }}
              />
            )}
            <TabFileIcon ext={tab.ext} />
            <span className="whitespace-nowrap font-mono text-[12px]">
              {tab.name}
            </span>
            <button
              onClick={(e) => closeTab(e, tab.name)}
              aria-label={`Close ${tab.name}`}
              className={cn(
                "flex h-4 w-4 items-center justify-center rounded-sm transition-colors"
              )}
              style={{
                color: isActive ? themeColors.text : "transparent",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = themeColors.text
                e.currentTarget.style.backgroundColor = `${themeColors.border}80`
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = isActive ? themeColors.text : "transparent"
                e.currentTarget.style.backgroundColor = "transparent"
              }}
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        )
      })}
    </div>
  )
}
