"use client"

import { useTheme } from "./theme-context"

interface Skill {
  name: string
  percentage: number
  color: string
}

interface SkillCategory {
  title: string
  skills: Skill[]
}

export function SkillsContent() {
  const { theme } = useTheme()
  const isDracula = theme === "dracula"

  const bgColor = isDracula ? "#282a36" : "#1E1E1E"
  const textColor = isDracula ? "#f8f8f2" : "#FFFFFF"
  const commentColor = isDracula ? "#6272a4" : "#49D0C3"
  const accentColor = isDracula ? "#8be9fd" : "#2DA8FF"
  const subtleColor = isDracula ? "#6272a4" : "#CCCCCC"

  const skillCategories: SkillCategory[] = [
    {
      title: "LANGUAGES",
      skills: [
        { name: "Python", percentage: 92, color: "#ff5555" },
        { name: "Java", percentage: 73, color: "#ff9e64" },
        { name: "JavaScript", percentage: 75, color: "#f1fa8c" },
        { name: "TypeScript", percentage: 74, color: "#8be9fd" },
        { name: "SQL", percentage: 88, color: "#bd93f9" },
      ],
    },
    {
      title: "GENERATIVE AI & LLM ENGINEERING",
      skills: [
        { name: "LangChain", percentage: 82, color: "#8be9fd" },
        { name: "RAG Pipelines", percentage: 85, color: "#50fa7b" },
        { name: "Prompt Engineering", percentage: 88, color: "#f1fa8c" },
        { name: "Agentic Workflows", percentage: 80, color: "#ff79c6" },
        { name: "Vector Search", percentage: 87, color: "#ffb86c" },
      ],
    },
    {
      title: "AI, ML, DATA SCIENCE",
      skills: [
        { name: "PyTorch", percentage: 85, color: "#ff5555" },
        { name: "TensorFlow", percentage: 80, color: "#ffb86c" },
        { name: "Scikit-learn", percentage: 78, color: "#50fa7b" },
        { name: "Pandas", percentage: 85, color: "#bd93f9" },
        { name: "NumPy", percentage: 87, color: "#8be9fd" },
        { name: "SciPy", percentage: 80, color: "#50fa7b" },
      ],
    },
    {
      title: "BACKEND & APIS",
      skills: [
        { name: "FastAPI", percentage: 90, color: "#50fa7b" },
        { name: "Flask", percentage: 82, color: "#8be9fd" },
        { name: "Django", percentage: 75, color: "#50fa7b" },
        { name: "Express", percentage: 78, color: "#f1fa8c" },
        { name: "NestJS", percentage: 76, color: "#bd93f9" },
      ],
    },
    {
      title: "DATABASES",
      skills: [
        { name: "PostgreSQL", percentage: 88, color: "#8be9fd" },
        { name: "Redis", percentage: 72, color: "#ff5555" },
        { name: "MongoDB", percentage: 80, color: "#f1fa8c" },
      ],
    },
    {
      title: "VECTOR DATABASES",
      skills: [
        { name: "Faiss", percentage: 82, color: "#8be9fd" },
        { name: "Pinecone", percentage: 78, color: "#bd93f9" },
        { name: "Weaviate", percentage: 75, color: "#50fa7b" },
      ],
    },
    {
      title: "DEVOPS & TOOLS",
      skills: [
        { name: "Docker", percentage: 80, color: "#8be9fd" },
        { name: "Git", percentage: 90, color: "#ffb86c" },
        { name: "GitHub Actions", percentage: 85, color: "#ff5555" },
        { name: "AWS", percentage: 74, color: "#ffb86c" },
        { name: "Vercel", percentage: 88, color: "#bd93f9" },
      ],
    },
    {
      title: "FRONTEND",
      skills: [
        { name: "React", percentage: 88, color: "#8be9fd" },
        { name: "Next.js", percentage: 85, color: "#bd93f9" },
        { name: "Vue.js", percentage: 72, color: "#50fa7b" },
        { name: "Responsive Design", percentage: 90, color: "#50fa7b" },
        { name: "Tailwind CSS", percentage: 88, color: "#8be9fd" },
      ],
    },
    {
      title: "DESIGN",
      skills: [
        { name: "Figma", percentage: 75, color: "#bd93f9" },
        { name: "UI Prototyping", percentage: 78, color: "#50fa7b" },
      ],
    },
    {
      title: "DATA ANALYTICS",
      skills: [
        { name: "Tableau", percentage: 73, color: "#ffb86c" },
        { name: "Power BI", percentage: 74, color: "#f1fa8c" },
      ],
    },
  ]

  const familiarTechs = [
    "Randal",
    "NumPy",
    "PyTorch/Libs",
    "QuicKit",
    "RLBfx",
    "OpenAI",
    "RAG",
    "FastLS",
    "PineconeAI",
    "LangChain",
  ]

  return (
    <div className="h-full overflow-y-auto p-6 font-mono" style={{ backgroundColor: bgColor, color: textColor }}>
      {/* Comment header */}
      <div className="mb-4 text-sm" style={{ color: commentColor }}>
        <div>// skills.json - Tech stack & tools i actively use</div>
      </div>

      {/* JSON-like interface declaration */}
      <div className="mb-6 text-sm" style={{ color: commentColor }}>
        interface Skills {"{"} "learning", "passion", "masterclass" {"}"}
      </div>

      {/* Skills title */}
      <h1 className="mb-8 text-4xl font-bold" style={{ color: textColor }}>
        Skills
      </h1>

      {/* Skills grid - 2 columns */}
      <div className="grid gap-x-8 gap-y-8 md:grid-cols-2">
        {skillCategories.map((category, idx) => (
          <div key={idx}>
            {/* Category title */}
            <div className="mb-4 flex items-center gap-3">
              <h2 className="text-xs font-bold uppercase tracking-widest" style={{ color: subtleColor }}>
                {category.title}
              </h2>
              <div className="flex-1 border-b" style={{ borderColor: subtleColor + "40" }} />
            </div>

            {/* Skills list */}
            <div className="space-y-3">
              {category.skills.map((skill) => (
                <div key={skill.name}>
                  {/* Skill name and percentage */}
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span style={{ color: textColor }}>{skill.name}</span>
                    <span style={{ color: skill.color }} className="font-semibold">
                      {skill.percentage}%
                    </span>
                  </div>

                  {/* Progress bar */}
                  <div
                    className="h-1.5 overflow-hidden rounded-full"
                    style={{ backgroundColor: subtleColor + "20" }}
                  >
                    <div
                      className="h-full transition-all"
                      style={{
                        width: `${skill.percentage}%`,
                        backgroundColor: skill.color,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Also familiar with section */}
      <div className="mt-12">
        <h3 className="mb-4 text-xs font-bold uppercase tracking-widest" style={{ color: subtleColor }}>
          Also familiar with
        </h3>
        <div className="flex flex-wrap gap-2">
          {familiarTechs.map((tech) => (
            <span
              key={tech}
              className="rounded border px-3 py-1 text-xs"
              style={{
                borderColor: subtleColor + "60",
                color: subtleColor,
              }}
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
