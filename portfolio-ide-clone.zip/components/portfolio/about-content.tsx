"use client"

import { useTheme } from "./theme-context"
import { Code2, Coffee, Guitar } from "lucide-react"

export function AboutContent() {
  const { theme } = useTheme()
  const isDracula = theme === "dracula"

  const bgColor = isDracula ? "#282a36" : "#1E1E1E"
  const textColor = isDracula ? "#f8f8f2" : "#FFFFFF"
  const commentColor = isDracula ? "#6272a4" : "#49D0C3"
  const accentColor = isDracula ? "#8be9fd" : "#2DA8FF"
  const subtleColor = isDracula ? "#6272a4" : "#CCCCCC"

  return (
    <div className="h-full overflow-y-auto p-6 font-mono" style={{ backgroundColor: bgColor, color: textColor }}>
      {/* Comment header */}
      <div className="mb-8 text-sm" style={{ color: commentColor }}>
        <div>// about.html - Aahana's Professional & Personal Story</div>
        <div>// Fullstack Developer | Problem Solver | Coffee & Code Enthusiast</div>
      </div>

      {/* Main content */}
      <div className="space-y-8">
        {/* Professional Summary */}
        <section>
          <h2 className="mb-4 text-2xl font-bold" style={{ color: accentColor }}>
            Professional Summary
          </h2>
          <div className="space-y-3 text-sm leading-relaxed" style={{ color: subtleColor }}>
            <p>
              I&apos;m a <span style={{ color: accentColor }}>fullstack developer</span> with <span style={{ color: accentColor }}>3+ years</span> of experience building high-performance web applications. My expertise spans from crafting seamless user interfaces to architecting scalable backend systems.
            </p>
            <p>
              Specializing in <span style={{ color: accentColor }}>Next.js</span>, <span style={{ color: accentColor }}>React</span>, and <span style={{ color: accentColor }}>PostgreSQL</span>, I focus on technical SEO optimization and delivering products that prioritize user experience. I believe great software solves real problems elegantly.
            </p>
          </div>
        </section>

        {/* Key Milestones */}
        <section>
          <h2 className="mb-4 text-2xl font-bold" style={{ color: accentColor }}>
            Key Milestones
          </h2>
          <ul className="space-y-3 text-sm" style={{ color: subtleColor }}>
            <li className="flex items-start gap-3">
              <span style={{ color: accentColor }} className="mt-1">›</span>
              <span>
                Developed <span style={{ color: accentColor }}>Ling&apos;s Home</span> - A comprehensive digital service management platform that streamlined operations for 100+ businesses
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span style={{ color: accentColor }} className="mt-1">›</span>
              <span>
                Mastered <span style={{ color: accentColor }}>technical SEO</span> and <span style={{ color: accentColor }}>performance optimization</span>, improving page load times by 60% on average
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span style={{ color: accentColor }} className="mt-1">›</span>
              <span>
                Built <span style={{ color: accentColor }}>AI-powered features</span> and <span style={{ color: accentColor }}>ML integrations</span> as part of EdTech solutions
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span style={{ color: accentColor }} className="mt-1">›</span>
              <span>
                Contributed to <span style={{ color: accentColor }}>10+ production projects</span> across e-commerce, SaaS, and education sectors
              </span>
            </li>
          </ul>
        </section>

        {/* Personal Interests */}
        <section>
          <h2 className="mb-4 text-2xl font-bold" style={{ color: accentColor }}>
            Beyond the Code
          </h2>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="flex items-start gap-3 rounded-md border p-3" style={{ borderColor: subtleColor + "40" }}>
              <Code2 size={20} style={{ color: accentColor }} className="mt-1 flex-shrink-0" />
              <div>
                <div className="font-semibold">Coding</div>
                <div className="text-xs" style={{ color: subtleColor }}>
                  Exploring new technologies and open-source contributions
                </div>
              </div>
            </div>
            <div className="flex items-start gap-3 rounded-md border p-3" style={{ borderColor: subtleColor + "40" }}>
              <Coffee size={20} style={{ color: accentColor }} className="mt-1 flex-shrink-0" />
              <div>
                <div className="font-semibold">Coffee</div>
                <div className="text-xs" style={{ color: subtleColor }}>
                  My fuel for debugging, thinking, and solving problems
                </div>
              </div>
            </div>
            <div className="flex items-start gap-3 rounded-md border p-3" style={{ borderColor: subtleColor + "40" }}>
              <Guitar size={20} style={{ color: accentColor }} className="mt-1 flex-shrink-0" />
              <div>
                <div className="font-semibold">Guitar</div>
                <div className="text-xs" style={{ color: subtleColor }}>
                  Balancing technical precision with creative expression
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Philosophy */}
        <section>
          <h2 className="mb-4 text-2xl font-bold" style={{ color: accentColor }}>
            My Philosophy
          </h2>
          <div className="rounded-md border border-l-4 p-4" style={{ borderColor: accentColor, borderLeftColor: accentColor }}>
            <p className="text-sm" style={{ color: subtleColor }}>
              &quot;Great software is built on three pillars: <span style={{ color: accentColor }}>clean code</span>, <span style={{ color: accentColor }}>user empathy</span>, and <span style={{ color: accentColor }}>continuous learning</span>. I strive to create products that are not just functional, but truly delightful to use.&quot;
            </p>
          </div>
        </section>
      </div>
    </div>
  )
}
