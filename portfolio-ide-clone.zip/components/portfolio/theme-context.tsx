"use client"

import { createContext, useContext, useState, useEffect, ReactNode } from "react"

export type Theme = "aahana-dark" | "dracula"

interface ThemeContextType {
  theme: Theme
  setTheme: (theme: Theme) => void
  toggleTheme: () => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>("aahana-dark")
  const [isHydrated, setIsHydrated] = useState(false)

  useEffect(() => {
    // Only run on client side after hydration
    setIsHydrated(true)
    const saved = localStorage.getItem("portfolio-theme") as Theme | null
    if (saved && (saved === "aahana-dark" || saved === "dracula")) {
      setThemeState(saved)
      applyTheme(saved)
    } else {
      applyTheme("aahana-dark")
    }
  }, [])

  const applyTheme = (newTheme: Theme) => {
    if (typeof window === "undefined") return
    const html = document.documentElement
    html.classList.remove("theme-dracula")
    if (newTheme === "dracula") {
      html.classList.add("theme-dracula")
    }
  }

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme)
    localStorage.setItem("portfolio-theme", newTheme)
    applyTheme(newTheme)
  }

  const toggleTheme = () => {
    const newTheme = theme === "aahana-dark" ? "dracula" : "aahana-dark"
    setTheme(newTheme)
  }

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }
  return context
}
