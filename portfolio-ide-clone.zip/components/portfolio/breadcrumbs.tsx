"use client"

import { ChevronRight } from "lucide-react"
import { useTheme } from "./theme-context"
import { cn } from "@/lib/utils"

interface BreadcrumbsProps {
  path: string[]
}

export function Breadcrumbs({ path }: BreadcrumbsProps) {
  const { theme } = useTheme()
  const isDracula = theme === "dracula"

  const bgColor = isDracula ? "bg-[#282a36]" : "bg-[#1E1E1E]"
  const textColor = isDracula ? "text-[#6272a4]/60" : "text-[#CCCCCC]/60"
  const textHover = isDracula ? "hover:text-[#f8f8f2]" : "hover:text-[#CCCCCC]"
  const textActive = isDracula ? "text-[#f8f8f2]" : "text-[#CCCCCC]"
  const chevronColor = isDracula ? "text-[#6272a4]/30" : "text-[#CCCCCC]/30"

  return (
    <div
      className={cn("flex h-7 shrink-0 items-center gap-1 border-b border-border px-4 font-mono text-[11px]", bgColor, textColor)}
    >
      {path.map((segment, i) => (
        <div key={i} className="flex items-center gap-1">
          {i > 0 && <ChevronRight className={cn("h-3 w-3", chevronColor)} />}
          <span
            className={cn(
              "cursor-pointer transition-colors",
              textHover,
              i === path.length - 1 ? textActive : ""
            )}
          >
            {segment}
          </span>
        </div>
      ))}
    </div>
  )
}
