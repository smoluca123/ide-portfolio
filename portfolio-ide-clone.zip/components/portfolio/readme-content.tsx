"use client"

import { useTheme } from "./theme-context"
import { ArrowRight, BookOpen, Code2, Eye, Zap } from "lucide-react"

export function ReadmeContent() {
  const { theme } = useTheme()
  const isDracula = theme === "dracula"

  const bgColor = isDracula ? "#282a36" : "#1E1E1E"
  const textColor = isDracula ? "#f8f8f2" : "#FFFFFF"
  const commentColor = isDracula ? "#6272a4" : "#49D0C3"
  const accentColor = isDracula ? "#8be9fd" : "#2DA8FF"
  const accentGreen = isDracula ? "#50fa7b" : "#49D0C3"
  const subtleColor = isDracula ? "#6272a4" : "#CCCCCC"

  const navigationItems = [
    {
      tab: "home.tsx",
      icon: <Eye size={18} />,
      description: "My personal intro and core stats",
    },
    {
      tab: "experience.ts",
      icon: <Code2 size={18} />,
      description: "Professional journey and roles",
    },
    {
      tab: "about.html",
      icon: <BookOpen size={18} />,
      description: "Background, philosophy, and interests",
    },
    {
      tab: "projects.js",
      icon: <Zap size={18} />,
      description: "Featured projects and impact",
    },
    {
      tab: "skills.json",
      icon: <Code2 size={18} />,
      description: "Technical expertise by category",
    },
    {
      tab: "contact.css",
      icon: <ArrowRight size={18} />,
      description: "Get in touch and connect",
    },
  ]

  return (
    <div className="h-full overflow-y-auto p-6 font-mono" style={{ backgroundColor: bgColor, color: textColor }}>
      {/* Header comment */}
      <div className="mb-8 text-sm" style={{ color: commentColor }}>
        <div>// README.md - Welcome to Aahana's Portfolio</div>
        <div>// A fullstack developer's playground and professional showcase</div>
      </div>

      {/* Main intro */}
      <div className="mb-8 space-y-4">
        <h1 className="text-3xl font-bold" style={{ color: accentColor }}>
          Aahana Bobade
        </h1>
        <p className="text-sm leading-relaxed" style={{ color: subtleColor }}>
          <span style={{ color: accentColor }}>Fullstack Developer</span> • <span style={{ color: accentGreen }}>Problem Solver</span> • <span style={{ color: accentColor }}>Perpetual Learner</span>
        </p>
      </div>

      {/* Mission statement */}
      <div
        className="mb-8 rounded-lg border-l-4 p-4"
        style={{
          borderColor: accentColor,
          backgroundColor: accentColor + "10",
        }}
      >
        <p className="text-sm" style={{ color: subtleColor }}>
          &quot;Building high-performance web products that prioritize user experience and technical excellence. From concept to production, I obsess over code quality, performance optimization, and solving real problems.&quot;
        </p>
      </div>

      {/* Quick stats */}
      <div className="mb-8">
        <h2 className="mb-4 text-lg font-bold" style={{ color: accentColor }}>
          Quick Facts
        </h2>
        <div className="grid gap-3 md:grid-cols-4">
          <div className="rounded p-3" style={{ backgroundColor: accentColor + "15" }}>
            <div className="text-lg font-bold" style={{ color: accentColor }}>
              3+
            </div>
            <div className="text-xs" style={{ color: subtleColor }}>
              Years Experience
            </div>
          </div>
          <div className="rounded p-3" style={{ backgroundColor: accentGreen + "15" }}>
            <div className="text-lg font-bold" style={{ color: accentGreen }}>
              10+
            </div>
            <div className="text-xs" style={{ color: subtleColor }}>
              Projects Built
            </div>
          </div>
          <div className="rounded p-3" style={{ backgroundColor: "#ff79c6" + "15" }}>
            <div className="text-lg font-bold" style={{ color: "#ff79c6" }}>
              100%
            </div>
            <div className="text-xs" style={{ color: subtleColor }}>
              Commitment
            </div>
          </div>
          <div className="rounded p-3" style={{ backgroundColor: "#ffb86c" + "15" }}>
            <div className="text-lg font-bold" style={{ color: "#ffb86c" }}>
              ∞
            </div>
            <div className="text-xs" style={{ color: subtleColor }}>
              Learning
            </div>
          </div>
        </div>
      </div>

      {/* Navigation guide */}
      <div>
        <h2 className="mb-4 text-lg font-bold" style={{ color: accentColor }}>
          Explore This Portfolio
        </h2>
        <div className="space-y-2">
          {navigationItems.map((item, index) => (
            <div
              key={index}
              className="flex items-start gap-3 rounded p-3 transition-colors hover:opacity-75"
              style={{ backgroundColor: "#262626" + "40" }}
            >
              <span style={{ color: accentGreen }} className="mt-1 flex-shrink-0">
                {item.icon}
              </span>
              <div>
                <div
                  className="text-sm font-semibold"
                  style={{ color: accentColor }}
                >
                  {item.tab}
                </div>
                <div className="text-xs" style={{ color: subtleColor }}>
                  {item.description}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div
        className="mt-8 rounded p-4 text-center text-xs"
        style={{
          backgroundColor: accentColor + "10",
          color: subtleColor,
        }}
      >
        <div style={{ color: commentColor }} className="mb-2">
          // Built with React, Next.js & Tailwind CSS
        </div>
        <div>
          Designed & developed by <span style={{ color: accentColor }}>Aahana Bobade</span>
        </div>
      </div>
    </div>
  )
}
