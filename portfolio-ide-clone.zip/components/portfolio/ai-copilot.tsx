"use client"

import { X, Send, Sparkles } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"
import { useTheme } from "./theme-context"

interface AICopilotProps {
  onClose: () => void
}

const suggestions = [
  "Tell me about Aahana?",
  "What projects has Aahana built?",
  "Tell me about her work experience",
  "What's her tech stack?",
  "How can I contact Aahana?",
  "How can I support Aahana?",
]

export function AICopilot({ onClose }: AICopilotProps) {
  const { theme } = useTheme()
  const [message, setMessage] = useState("")

  const isDracula = theme === "dracula"
  
  const bgColor = isDracula ? "bg-[#282a36]" : "bg-[#1A1A1A]"
  const borderColor = isDracula ? "border-[#44475a]" : "border-[#374151]"
  const surfaceColor = isDracula ? "bg-[#44475a]" : "bg-[#262626]"
  const textColor = isDracula ? "text-[#f8f8f2]" : "text-white"
  const textSecondary = isDracula ? "text-[#6272a4]" : "text-[#CCCCCC]/60"
  const textTertiary = isDracula ? "text-[#6272a4]/50" : "text-[#CCCCCC]/30"
  const accentColor = isDracula ? "text-[#8be9fd]" : "text-[#2DA8FF]"
  const accentBg = isDracula ? "bg-[#8be9fd]/15 text-[#8be9fd]" : "bg-[#2DA8FF]/15 text-[#2DA8FF]"
  const accentHover = isDracula ? "border-[#8be9fd]/50 hover:text-[#f8f8f2]" : "border-[#2DA8FF]/50 hover:text-[#CCCCCC]"
  const accentBtnBg = isDracula ? "bg-[#8be9fd]" : "bg-[#2DA8FF]"
  const accentBtnHover = isDracula ? "hover:bg-[#8be9fd]/80" : "hover:bg-[#2DA8FF]/80"
  const sparklesColor = isDracula ? "text-[#ff79c6]" : "text-[#FF61D8]"
  const hoverBg = isDracula ? "hover:bg-[#44475a]" : "hover:bg-[#262626]"

  return (
    <div
      className={cn("flex h-full w-72 shrink-0 flex-col border-l", bgColor, borderColor)}
    >
      {/* Header */}
      <div className={cn("flex shrink-0 items-center justify-between border-b px-4 py-2.5", borderColor)}>
        <div className="flex items-center gap-2">
          <Sparkles className={cn("h-4 w-4", sparklesColor)} />
          <span className={cn("font-mono text-[13px] font-semibold", textColor)}>
            Aahana&apos;s AI Assistant
          </span>
        </div>
        <button
          onClick={onClose}
          aria-label="Close AI Assistant"
          className={cn(
            "flex h-6 w-6 items-center justify-center rounded-sm transition-colors",
            isDracula ? "text-[#6272a4]/50 hover:bg-[#44475a] hover:text-[#f8f8f2]" : "text-[#CCCCCC]/50 hover:bg-[#262626] hover:text-[#CCCCCC]"
          )}
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Workspace pill */}
      <div className={cn("shrink-0 border-b px-4 py-2", borderColor)}>
        <div className="flex items-center gap-2">
          <span className={cn("font-mono text-[10px] uppercase tracking-[0.12em]", isDracula ? "text-[#6272a4]/40" : "text-[#CCCCCC]/40")}>
            Workspace
          </span>
          <span className={cn("rounded-sm px-2 py-0.5 font-mono text-[10px]", accentBg)}>
            ● portfolio · aahana-bobade
          </span>
        </div>
      </div>

      {/* Body */}
      <div className="flex flex-1 flex-col overflow-y-auto p-4">
        {/* Avatar + greeting */}
        <div className="mb-6 flex flex-col items-center text-center">
          <div className={cn("mb-3 flex h-14 w-14 items-center justify-center rounded-full border", surfaceColor, borderColor)}>
            <span className={cn("text-2xl", sparklesColor)}>✦</span>
          </div>
          <h3 className={cn("mb-1 font-serif text-[16px] font-bold", textColor)}>
            Hi! I&apos;m Aahana&apos;s Copilot
          </h3>
          <p className={cn("font-mono text-[11px] leading-relaxed", textSecondary)}>
            Ask me anything about her projects, skills, experience, or achievements.
          </p>
        </div>

        {/* Suggestion chips */}
        <div className="grid grid-cols-2 gap-1.5">
          {suggestions.map((s, i) => (
            <button
              key={i}
              onClick={() => setMessage(s)}
              className={cn(
                "rounded-sm border px-2.5 py-2 text-left font-mono text-[10px] transition-colors",
                surfaceColor,
                borderColor,
                isDracula ? "text-[#6272a4]/70 hover:border-[#8be9fd]/50 hover:text-[#f8f8f2]" : "text-[#CCCCCC]/70 hover:border-[#2DA8FF]/50 hover:text-[#CCCCCC]"
              )}
            >
              ✦ {s}
            </button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className={cn("shrink-0 border-t p-3", borderColor)}>
        <div className="relative">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Ask about Aahana's projects, experience, skills..."
            className={cn(
              "w-full rounded-sm border px-3 py-2 pr-10 font-mono text-[11px] placeholder:transition-colors focus:outline-none",
              surfaceColor,
              borderColor,
              textColor,
              isDracula 
                ? "placeholder:text-[#6272a4]/30 focus:border-[#8be9fd]" 
                : "placeholder:text-[#CCCCCC]/30 focus:border-[#2DA8FF]"
            )}
          />
          <button
            aria-label="Send message"
            className={cn(
              "absolute right-2 top-1/2 -translate-y-1/2 flex h-6 w-6 items-center justify-center rounded-sm transition-colors",
              message
                ? cn(accentBtnBg, "text-white", accentBtnHover)
                : textTertiary
            )}
          >
            <Send className="h-3 w-3" />
          </button>
        </div>
        <p className={cn("mt-2 text-center font-mono text-[9px]", textTertiary)}>
          3 msgs left
        </p>
        <p className={cn("mt-1 text-center font-mono text-[9px]", textTertiary)}>
          AI can make mistakes · Contact Aahana directly for{" "}
          <span className={accentColor}>important info</span>
        </p>
      </div>
    </div>
  )
}
