"use client"

import { useState, useRef, useEffect, KeyboardEvent } from "react"
import { X, ChevronUp, ChevronDown, Palette, TerminalSquare, AlertCircle, FileText } from "lucide-react"
import { useTheme } from "./theme-context"

interface HistoryEntry {
  type: "command" | "output" | "error" | "success" | "info"
  content: string
  timestamp?: Date
}

const COMMANDS: Record<string, { description: string; output: string | string[] }> = {
  help: {
    description: "Show available commands",
    output: [
      "Available commands:",
      "",
      "  help      - Show this help message",
      "  clear     - Clear terminal history",
      "  about     - Learn about Aahana",
      "  skills    - View technical skills",
      "  projects  - List featured projects",
      "  contact   - Get contact information",
      "  theme     - Toggle theme (Aahana Dark / Dracula)",
      "  whoami    - Display current user",
      "  pwd       - Print working directory",
      "  date      - Display current date and time",
      "  exit      - Close the terminal panel",
      "",
      "Tip: Use Tab for autocomplete, Arrow keys for history",
    ],
  },
  about: {
    description: "Learn about Aahana",
    output: [
      "┌─────────────────────────────────────────────┐",
      "│  Aahana Bobade                              │",
      "│  Junior Software Developer                  │",
      "│                                             │",
      "│  Passionate about building intelligent      │",
      "│  backend systems and AI integrations.       │",
      "│  Currently working at EduVanceAI.           │",
      "└─────────────────────────────────────────────┘",
    ],
  },
  skills: {
    description: "View technical skills",
    output: [
      "Technical Skills:",
      "",
      "  Languages   : Python, TypeScript, JavaScript, SQL",
      "  Backend     : FastAPI, Django, Node.js, PostgreSQL",
      "  Frontend    : React, Next.js, Tailwind CSS",
      "  DevOps      : Docker, AWS, CI/CD, Git",
      "  AI/ML       : RAG Pipelines, LangChain, GenAI",
    ],
  },
  projects: {
    description: "List featured projects",
    output: [
      "Featured Projects:",
      "",
      "  1. EdTech AI Platform",
      "     ML-powered personalization for learners",
      "",
      "  2. Portfolio IDE",
      "     VS Code inspired portfolio (you are here!)",
      "",
      "  3. Backend API Framework",
      "     Scalable FastAPI microservices template",
    ],
  },
  contact: {
    description: "Get contact information",
    output: [
      "Contact Information:",
      "",
      "  Email    : aahana@example.com",
      "  GitHub   : github.com/aahana-bobade",
      "  LinkedIn : linkedin.com/in/aahana-bobade",
    ],
  },
  whoami: {
    description: "Display current user",
    output: "aahana",
  },
  pwd: {
    description: "Print working directory",
    output: "/home/aahana/portfolio",
  },
  date: {
    description: "Display current date",
    output: "", // Will be set dynamically
  },
  theme: {
    description: "Toggle theme",
    output: "", // Will be set dynamically
  },
  clear: {
    description: "Clear terminal",
    output: "",
  },
  exit: {
    description: "Close terminal",
    output: "Closing terminal...",
  },
}

const SUGGESTIONS = ["help", "about", "skills", "projects", "contact", "theme"]

interface TerminalProps {
  onClose?: () => void
  isMinimized?: boolean
  onToggleMinimize?: () => void
}

export function Terminal({ onClose, isMinimized = false, onToggleMinimize }: TerminalProps) {
  const { theme, toggleTheme } = useTheme()
  const [history, setHistory] = useState<HistoryEntry[]>([
    { type: "success", content: "Welcome! Type 'help' to see available commands." },
  ])
  const [input, setInput] = useState("")
  const [commandHistory, setCommandHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [activeTab, setActiveTab] = useState<"terminal" | "problems" | "output">("terminal")
  
  const inputRef = useRef<HTMLInputElement>(null)
  const outputRef = useRef<HTMLDivElement>(null)

  // Theme-aware colors
  const colors = {
    bg: theme === "dracula" ? "#282a36" : "#1E1E1E",
    header: theme === "dracula" ? "#21222c" : "#1A1A1A",
    surface: theme === "dracula" ? "#44475a" : "#262626",
    border: theme === "dracula" ? "#44475a" : "#374151",
    text: theme === "dracula" ? "#f8f8f2" : "#CCCCCC",
    textMuted: theme === "dracula" ? "#6272a4" : "#808080",
    success: theme === "dracula" ? "#50fa7b" : "#4EC994",
    error: theme === "dracula" ? "#ff5555" : "#FF5A5F",
    accent: theme === "dracula" ? "#bd93f9" : "#2DA8FF",
    pink: theme === "dracula" ? "#ff79c6" : "#FF61D8",
    cyan: theme === "dracula" ? "#8be9fd" : "#49D0C3",
    yellow: theme === "dracula" ? "#f1fa8c" : "#FACC15",
    orange: theme === "dracula" ? "#ffb86c" : "#F97316",
  }

  // Auto-scroll to bottom when history changes
  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight
    }
  }, [history])

  // Focus input when terminal becomes visible
  useEffect(() => {
    if (!isMinimized && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isMinimized])

  const executeCommand = (cmd: string) => {
    const trimmed = cmd.trim().toLowerCase()
    
    // Add command to history display
    setHistory((prev) => [...prev, { type: "command", content: `$ ${cmd}` }])
    
    // Add to command history for arrow navigation
    if (trimmed) {
      setCommandHistory((prev) => [...prev.filter((c) => c !== trimmed), trimmed])
    }
    setHistoryIndex(-1)

    if (!trimmed) return

    if (trimmed === "clear") {
      setHistory([])
      return
    }

    if (trimmed === "exit") {
      setHistory((prev) => [...prev, { type: "output", content: "Closing terminal..." }])
      setTimeout(() => onClose?.(), 500)
      return
    }

    if (trimmed === "theme") {
      toggleTheme()
      const newTheme = theme === "aahana-dark" ? "Dracula" : "Aahana Dark"
      setHistory((prev) => [
        ...prev,
        { type: "success", content: `Theme switched to ${newTheme}` },
      ])
      return
    }

    if (trimmed === "date") {
      const now = new Date()
      setHistory((prev) => [
        ...prev,
        { type: "output", content: now.toLocaleString() },
      ])
      return
    }

    const command = COMMANDS[trimmed]
    if (command) {
      const output = Array.isArray(command.output) ? command.output : [command.output]
      output.forEach((line) => {
        if (line) {
          setHistory((prev) => [...prev, { type: "output", content: line }])
        }
      })
    } else {
      setHistory((prev) => [
        ...prev,
        { type: "error", content: `Command not found: ${trimmed}. Type 'help' for available commands.` },
      ])
    }
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      executeCommand(input)
      setInput("")
      setShowSuggestions(false)
    } else if (e.key === "ArrowUp") {
      e.preventDefault()
      if (commandHistory.length > 0) {
        const newIndex = historyIndex < commandHistory.length - 1 ? historyIndex + 1 : historyIndex
        setHistoryIndex(newIndex)
        setInput(commandHistory[commandHistory.length - 1 - newIndex] || "")
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault()
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1
        setHistoryIndex(newIndex)
        setInput(commandHistory[commandHistory.length - 1 - newIndex] || "")
      } else if (historyIndex === 0) {
        setHistoryIndex(-1)
        setInput("")
      }
    } else if (e.key === "Tab") {
      e.preventDefault()
      const matches = Object.keys(COMMANDS).filter((cmd) => cmd.startsWith(input.toLowerCase()))
      if (matches.length === 1) {
        setInput(matches[0])
        setShowSuggestions(false)
      } else if (matches.length > 1) {
        setShowSuggestions(true)
      }
    } else if (e.key === "Escape") {
      setShowSuggestions(false)
    }
  }

  const filteredSuggestions = input
    ? Object.keys(COMMANDS).filter((cmd) => cmd.startsWith(input.toLowerCase()))
    : []

  const tabs = [
    { id: "terminal" as const, label: "TERMINAL", icon: TerminalSquare },
    { id: "problems" as const, label: "PROBLEMS", icon: AlertCircle },
    { id: "output" as const, label: "OUTPUT", icon: FileText },
  ]

  if (isMinimized) {
    return null
  }

  return (
    <div 
      className="flex flex-col border-t" 
      style={{ background: colors.bg, borderColor: colors.border }}
    >
      {/* Terminal Header with Tabs */}
      <div 
        className="flex h-9 items-center justify-between border-b px-2" 
        style={{ background: colors.header, borderColor: colors.border }}
      >
        <div className="flex items-center gap-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex items-center gap-1.5 px-3 py-1.5 font-mono text-[11px] uppercase tracking-wide transition-colors"
              style={{
                color: activeTab === tab.id ? "#fff" : colors.textMuted,
                borderBottom: activeTab === tab.id ? `2px solid ${colors.accent}` : "2px solid transparent",
              }}
            >
              <tab.icon className="h-3 w-3" />
              {tab.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1">
          {/* Theme toggle */}
          <button
            onClick={toggleTheme}
            className="rounded p-1 transition-colors hover:bg-opacity-50"
            style={{ color: colors.textMuted }}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = colors.surface}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "transparent"}
            aria-label="Toggle theme"
            title={`Switch to ${theme === "aahana-dark" ? "Dracula" : "Aahana Dark"} theme`}
          >
            <Palette className="h-4 w-4" />
          </button>
          <button
            onClick={onToggleMinimize}
            className="rounded p-1 transition-colors"
            style={{ color: colors.textMuted }}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = colors.surface}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "transparent"}
            aria-label="Minimize terminal"
          >
            <ChevronDown className="h-4 w-4" />
          </button>
          <button
            onClick={onToggleMinimize}
            className="rounded p-1 transition-colors"
            style={{ color: colors.textMuted }}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = colors.surface}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "transparent"}
            aria-label="Maximize terminal"
          >
            <ChevronUp className="h-4 w-4" />
          </button>
          <button
            onClick={onClose}
            className="rounded p-1 transition-colors"
            style={{ color: colors.textMuted }}
            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = colors.surface}
            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "transparent"}
            aria-label="Close terminal"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Terminal Content */}
      <div className="flex flex-1 flex-col" style={{ minHeight: "200px", maxHeight: "300px" }}>
        {activeTab === "terminal" ? (
          <>
            {/* Output Area */}
            <div
              ref={outputRef}
              className="flex-1 overflow-y-auto p-3 font-mono text-[13px] leading-relaxed"
              onClick={() => inputRef.current?.focus()}
            >
              {history.map((entry, i) => (
                <div
                  key={i}
                  className="whitespace-pre-wrap"
                  style={{
                    color:
                      entry.type === "command"
                        ? colors.text
                        : entry.type === "error"
                          ? colors.error
                          : entry.type === "success"
                            ? colors.success
                            : entry.type === "info"
                              ? colors.cyan
                              : colors.textMuted,
                  }}
                >
                  {entry.content}
                </div>
              ))}

              {/* Autocomplete suggestions */}
              {showSuggestions && filteredSuggestions.length > 1 && (
                <div className="mt-2 flex flex-wrap gap-2">
                  {filteredSuggestions.map((suggestion) => (
                    <button
                      key={suggestion}
                      onClick={() => {
                        setInput(suggestion)
                        setShowSuggestions(false)
                        inputRef.current?.focus()
                      }}
                      className="rounded border px-2 py-0.5 font-mono text-[11px] transition-colors"
                      style={{
                        borderColor: colors.border,
                        backgroundColor: colors.surface,
                        color: colors.accent,
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.borderColor = colors.accent}
                      onMouseLeave={(e) => e.currentTarget.style.borderColor = colors.border}
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Bottom section with input */}
            <div className="border-t" style={{ borderColor: colors.border }}>
              {/* Command Input */}
              <div className="flex items-center gap-2 px-3 py-2">
                <span className="font-mono text-[13px]" style={{ color: colors.success }}>aahana</span>
                <span className="font-mono text-[13px]" style={{ color: colors.cyan }}>@portfolio</span>
                <span className="font-mono text-[13px]" style={{ color: colors.textMuted }}>: ~ $</span>
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={(e) => {
                    setInput(e.target.value)
                    setShowSuggestions(e.target.value.length > 0)
                  }}
                  onKeyDown={handleKeyDown}
                  className="flex-1 bg-transparent font-mono text-[13px] outline-none"
                  style={{ color: "#fff" }}
                  placeholder="Type a command..."
                  autoComplete="off"
                  spellCheck={false}
                  aria-label="Terminal input"
                />
              </div>
            </div>
          </>
        ) : activeTab === "problems" ? (
          <div className="flex flex-1 items-center justify-center p-4">
            <p className="font-mono text-[13px]" style={{ color: colors.textMuted }}>
              No problems detected in workspace.
            </p>
          </div>
        ) : (
          <div className="flex flex-1 items-center justify-center p-4">
            <p className="font-mono text-[13px]" style={{ color: colors.textMuted }}>
              No output to display.
            </p>
          </div>
        )}
      </div>

      {/* Quick Suggestions */}
      {activeTab === "terminal" && (
        <div 
          className="flex flex-wrap items-center gap-2 border-t px-3 py-2" 
          style={{ background: colors.header, borderColor: colors.border }}
        >
          <span className="font-mono text-[10px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
            Try:
          </span>
          {SUGGESTIONS.map((suggestion) => (
            <button
              key={suggestion}
              onClick={() => {
                setInput(suggestion)
                inputRef.current?.focus()
              }}
              className="rounded border px-2 py-0.5 font-mono text-[10px] transition-colors"
              style={{
                borderColor: colors.border,
                backgroundColor: colors.surface,
                color: colors.text,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = colors.accent
                e.currentTarget.style.color = colors.accent
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = colors.border
                e.currentTarget.style.color = colors.text
              }}
            >
              {suggestion}
            </button>
          ))}
          {/* Theme indicator */}
          <span 
            className="ml-auto flex items-center gap-1 rounded px-2 py-0.5 font-mono text-[10px]"
            style={{ backgroundColor: colors.surface, color: colors.accent }}
          >
            <Palette className="h-2.5 w-2.5" />
            {theme === "dracula" ? "Dracula" : "Aahana Dark"}
          </span>
        </div>
      )}
    </div>
  )
}
