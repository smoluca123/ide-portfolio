"use client"

import { GitBranch, AlertCircle, Sparkles, Heart } from "lucide-react"
import { useEffect, useState } from "react"
import { useTheme } from "./theme-context"

export function StatusBar() {
  const { theme, toggleTheme } = useTheme()
  const [time, setTime] = useState("")

  useEffect(() => {
    const update = () => {
      const d = new Date()
      setTime(
        d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })
      )
    }
    update()
    const id = setInterval(update, 10000)
    return () => clearInterval(id)
  }, [])

  // Theme-aware colors
  const bgColor = theme === "dracula" ? "#bd93f9" : "#0078d4"
  const themeName = theme === "dracula" ? "Dracula" : "Aahana Dark"

  return (
    <div
      className="flex h-6 shrink-0 items-center justify-between px-3 font-mono text-[11px] text-white"
      style={{ background: bgColor }}
    >
      {/* Left */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1">
          <GitBranch className="h-3 w-3" />
          <span>main</span>
        </div>
        <div className="flex items-center gap-1 opacity-80">
          <AlertCircle className="h-3 w-3" />
          <span>0</span>
        </div>
        <span className="opacity-80">
          <span className="text-yellow-200">↑1</span>
          {" "}
          <span className="text-green-200">+3</span>
        </span>
      </div>

      {/* Center */}
      <div className="flex items-center gap-1.5 opacity-90">
        <GitBranch className="h-3 w-3" />
        <span>main</span>
        <span className="opacity-50">|</span>
        <span>Aahana&apos;s Portfolio</span>
      </div>

      {/* Right */}
      <div className="flex items-center gap-3 opacity-90">
        <div className="flex items-center gap-1">
          <Sparkles className="h-3 w-3" />
          <span>Copilot</span>
        </div>
        <span>TypeScript React</span>
        <span>UTF-8</span>
        <span>Prettier</span>
        <button
          onClick={toggleTheme}
          className="flex items-center gap-1 rounded px-1.5 py-0.5 transition-colors hover:bg-white/20"
          title={`Click to switch theme`}
        >
          <Heart className="h-2.5 w-2.5" />
          <span>{themeName}</span>
        </button>
        {time && <span className="tabular-nums">{time}</span>}
      </div>
    </div>
  )
}
