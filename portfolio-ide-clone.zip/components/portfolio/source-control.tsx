"use client"

import { Github, ChevronDown } from "lucide-react"
import { useTheme } from "./theme-context"

export interface SourceControlProps {
  branch?: string
  commitsAhead?: number
  modified?: number
  added?: number
  deleted?: number
}

export function SourceControl({
  branch = "main",
  commitsAhead = 1,
  modified = 3,
  added = 1,
  deleted = 0,
}: SourceControlProps) {
  const { theme } = useTheme()

  const isDracula = theme === "dracula"

  // Theme colors
  const bgColor = isDracula ? "#282a36" : "#1E1E1E"
  const textColor = isDracula ? "#f8f8f2" : "#FFFFFF"
  const labelColor = isDracula ? "#6272a4" : "#CCCCCC"
  const modifiedColor = isDracula ? "#ffb86c" : "#FFA500"
  const addedColor = isDracula ? "#8be9fd" : "#49D0C3"
  const deletedColor = isDracula ? "#ff5555" : "#FF5A5F"
  const linkColor = isDracula ? "#8be9fd" : "#2DA8FF"
  const hoverBg = isDracula ? "#44475a" : "#262626"

  return (
    <div
      className="flex flex-col gap-6 overflow-y-auto p-4 text-sm"
      style={{ backgroundColor: bgColor, color: textColor }}
    >
      {/* Header */}
      <div className="space-y-4">
        <h2
          className="text-xs font-semibold uppercase tracking-wider"
          style={{ color: labelColor }}
        >
          Source Control
        </h2>

        {/* Branch Info */}
        <div className="rounded-md border p-3" style={{ borderColor: isDracula ? "#44475a" : "#374151" }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Github size={16} style={{ color: linkColor }} />
              <span className="font-mono" style={{ color: textColor }}>
                {branch}
              </span>
            </div>
            {commitsAhead > 0 && (
              <span className="text-xs" style={{ color: addedColor }}>
                ↑ {commitsAhead} commit{commitsAhead !== 1 ? "s" : ""} ahead
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="space-y-3">
        <div className="flex justify-around gap-2">
          {/* Modified */}
          <div className="flex flex-1 flex-col items-center gap-2 rounded-md border p-4" style={{ borderColor: isDracula ? "#44475a" : "#374151" }}>
            <span
              className="text-2xl font-bold font-mono"
              style={{ color: modifiedColor }}
            >
              {modified}
            </span>
            <span className="text-xs uppercase tracking-wide" style={{ color: labelColor }}>
              Modified
            </span>
          </div>

          {/* Added */}
          <div className="flex flex-1 flex-col items-center gap-2 rounded-md border p-4" style={{ borderColor: isDracula ? "#44475a" : "#374151" }}>
            <span
              className="text-2xl font-bold font-mono"
              style={{ color: addedColor }}
            >
              {added}
            </span>
            <span className="text-xs uppercase tracking-wide" style={{ color: labelColor }}>
              Added
            </span>
          </div>

          {/* Deleted */}
          <div className="flex flex-1 flex-col items-center gap-2 rounded-md border p-4" style={{ borderColor: isDracula ? "#44475a" : "#374151" }}>
            <span
              className="text-2xl font-bold font-mono"
              style={{ color: deletedColor }}
            >
              {deleted}
            </span>
            <span className="text-xs uppercase tracking-wide" style={{ color: labelColor }}>
              Deleted
            </span>
          </div>
        </div>
      </div>

      {/* GitHub Link */}
      <a
        href="https://github.com"
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-2 text-xs transition-colors hover:opacity-80"
        style={{ color: linkColor }}
      >
        <span>View on GitHub</span>
        <span>↗</span>
      </a>
    </div>
  )
}
