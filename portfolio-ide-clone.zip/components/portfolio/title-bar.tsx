"use client"

import { Search } from "lucide-react"
import { useTheme } from "./theme-context"

const menuItems = ["File", "Edit", "View", "Go", "Run", "Terminal", "Help", "Copilot"]

interface TitleBarProps {
  onCommandPaletteOpen?: () => void
}

export function TitleBar({ onCommandPaletteOpen }: TitleBarProps) {
  const { theme } = useTheme()
  
  const themeColors = {
    bg: theme === "dracula" ? "#282a36" : "#1A1A1A",
    border: theme === "dracula" ? "#44475a" : "#374151",
    text: theme === "dracula" ? "#f8f8f2" : "#CCCCCC",
    textMuted: theme === "dracula" ? "#6272a4" : "#CCCCCC",
    textMutedLight: theme === "dracula" ? "#6272a4" : "#CCCCCC/70",
    surface: theme === "dracula" ? "#3f4148" : "#262626",
    accent: theme === "dracula" ? "#50fa7b" : "#2DA8FF",
  }

  return (
    <div
      className="relative flex h-9 shrink-0 items-center justify-between border-b px-3"
      style={{ 
        background: themeColors.bg,
        borderColor: themeColors.border,
      }}
    >
      {/* macOS traffic lights + menu */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <div className="h-3 w-3 cursor-pointer rounded-full bg-[#FF5F56] transition-opacity hover:opacity-80" />
          <div className="h-3 w-3 cursor-pointer rounded-full bg-[#FFBD2E] transition-opacity hover:opacity-80" />
          <div className="h-3 w-3 cursor-pointer rounded-full bg-[#27C93F] transition-opacity hover:opacity-80" />
        </div>
        <nav className="hidden items-center gap-0.5 md:flex">
          {menuItems.map((item) => (
            <button
              key={item}
              className="rounded-sm px-2 py-1 font-mono text-[11px] transition-colors hover:bg-opacity-50"
              style={{ 
                color: themeColors.text,
                backgroundColor: "transparent",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = themeColors.surface
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = "transparent"
              }}
            >
              {item}
            </button>
          ))}
        </nav>
      </div>

      {/* Centered command palette */}
      <div 
        className="absolute left-1/2 -translate-x-1/2 flex cursor-pointer items-center gap-2 rounded-md border px-3 py-1 transition-colors hover:border-opacity-50"
        style={{ 
          borderColor: themeColors.border,
          backgroundColor: themeColors.surface,
        }}
        onClick={onCommandPaletteOpen}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            onCommandPaletteOpen?.()
          }
        }}
        aria-label="Open command palette"
      >
        <Search className="h-3 w-3" style={{ color: themeColors.textMuted }} />
        <span className="font-mono text-[11px]" style={{ color: themeColors.text }}>
          aahana-bobade&nbsp;:&nbsp;portfolio
        </span>
        <span 
          className="rounded-sm px-1 font-mono text-[9px]"
          style={{ 
            backgroundColor: themeColors.bg,
            color: themeColors.textMuted,
          }}
        >
          Ctrl P
        </span>
      </div>

      {/* Spacer */}
      <div className="w-24" />
    </div>
  )
}
