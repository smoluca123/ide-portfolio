"use client"

import { useTheme } from "./theme-context"
import { cn } from "@/lib/utils"
import { Github, Linkedin, Mail, Globe, BookOpen, Code2 } from "lucide-react"

const socialLinks = [
  { icon: Github, label: "GitHub", href: "#" },
  { icon: Linkedin, label: "LinkedIn", href: "#" },
  { icon: Globe, label: "Medium", href: "#" },
  { icon: BookOpen, label: "Tableau", href: "#" },
  { icon: Code2, label: "LeetCode", href: "#" },
  { icon: Mail, label: "Email", href: "#" },
]

const stats = [
  { value: "3+", label: "YEARS" },
  { value: "10+", label: "PROJECTS" },
  { value: "∞", label: "CURIOSITY" },
  { value: "↑", label: "ALWAYS LEARNING" },
]

export function HomeContent() {
  const { theme } = useTheme()
  const isDracula = theme === "dracula"

  const bgColor = isDracula ? "bg-[#282a36]" : "bg-[#1E1E1E]"
  const commentColor = isDracula ? "text-[#6272a4]/80" : "text-[#49D0C3]/80"
  const textColor = isDracula ? "text-[#f8f8f2]" : "text-white"
  const textSecondary = isDracula ? "text-[#6272a4]/60" : "text-[#CCCCCC]/80"
  const textTertiary = isDracula ? "text-[#6272a4]/50" : "text-[#CCCCCC]/70"
  const accentBlue = isDracula ? "text-[#8be9fd]" : "text-[#2DA8FF]"
  const accentCyan = isDracula ? "text-[#50fa7b]" : "text-[#49D0C3]"
  const accentPink = isDracula ? "text-[#ff79c6]" : "text-[#FF61D8]"
  const accentPink2 = isDracula ? "text-[#ff79c6] border-[#ff79c6]/40 bg-[#ff79c6]/10" : "text-[#FF61D8] border-[#FF61D8]/40 bg-[#FF61D8]/10"
  const borderColor = isDracula ? "border-[#44475a]" : "border-[#374151]"
  const surfaceColor = isDracula ? "bg-[#44475a]/50" : "bg-[#262626]/50"
  const hoverBgColor = isDracula ? "hover:bg-[#44475a]" : "hover:bg-[#262626]"
  const hoverBorderColor = isDracula ? "hover:border-[#8be9fd]/50" : "hover:border-[#2DA8FF]/50"
  const buttonHoverBg = isDracula ? "hover:bg-[#44475a]" : "hover:bg-[#262626]"
  const buttonBg = isDracula ? "bg-[#8be9fd]" : "bg-[#2DA8FF]"
  const buttonText = isDracula ? "text-[#282a36]" : "text-[#1E1E1E]"
  const buttonHover = isDracula ? "hover:bg-[#8be9fd]/80 hover:border-[#8be9fd]/60" : "hover:bg-[#5EC8FF] hover:border-[#5EC8FF]/60"
  const borderSecondary = isDracula ? "border-[#6272a4]/30" : "border-[#CCCCCC]/30"

  return (
    <div className={cn("flex-1 overflow-y-auto px-10 py-8", bgColor)}>
      {/* Code comment */}
      <p className={cn("mb-8 font-mono text-[13px] italic", commentColor)}>
        {"// hello world !! Welcome to my portfolio"}
      </p>

      {/* Hero Name — Syne serif */}
      <div className="mb-8">
        <h1 className={cn("font-serif text-[84px] font-extrabold leading-none", textColor)} style={{ letterSpacing: "-0.03em" }}>
          Aahana
        </h1>
        <h1 className={cn("font-serif text-[84px] font-extrabold leading-none", accentPink)} style={{ letterSpacing: "-0.03em" }}>
          Bobade
        </h1>
      </div>

      {/* Skills badges */}
      <div className="mb-8 flex flex-wrap gap-3">
        <span className={cn("rounded-sm border bg-opacity-5 px-3 py-1.5 font-mono text-[11px] font-medium", borderSecondary, textSecondary)}>
          Backend Engineer
        </span>
        <span className={cn("rounded-sm border px-3 py-1.5 font-mono text-[11px] font-medium", isDracula ? "border-[#8be9fd]/40 bg-[#8be9fd]/10 text-[#8be9fd]" : "border-[#2DA8FF]/40 bg-[#2DA8FF]/10 text-[#2DA8FF]")}>
          AI / ML Dev
        </span>
        <span className={cn("rounded-sm border px-3 py-1.5 font-mono text-[11px] font-medium", isDracula ? "border-[#50fa7b]/40 bg-[#50fa7b]/10 text-[#50fa7b]" : "border-[#49D0C3]/40 bg-[#49D0C3]/10 text-[#49D0C3]")}>
          Data Scientist
        </span>
        <span className={cn("rounded-sm border px-3 py-1.5 font-mono text-[11px] font-medium", accentPink2)}>
          EduVanceAI
        </span>
      </div>

      {/* Turning text with cursor */}
      <p className={cn("mb-6 font-mono text-[13px]", textSecondary)}>
        <span className={cn("font-bold", accentPink)}>Turning</span> <span className={cn("animate-pulse", accentBlue)}>|</span>
      </p>

      {/* Description */}
      <p className={cn("mb-8 max-w-3xl font-mono text-[14px] leading-relaxed", textSecondary)}>
        I live at the crossroads of{" "}
        <span className={cn("font-semibold", accentBlue)}>backend engineering</span>,{" "}
        <span className={cn("font-semibold", accentBlue)}>AI/ML</span>, and{" "}
        <span className={cn("font-semibold", accentBlue)}>data science</span>. I build systems that are genuinely{" "}
        <span className={cn("font-semibold", accentCyan)}>intelligent</span> and{" "}
        <span className={cn("font-semibold", accentCyan)}>scalable</span>.
      </p>

      {/* Action buttons */}
      <div className="mb-16 flex gap-4">
        <button
          className={cn("rounded-sm border px-4 py-2 font-mono text-[12px] font-semibold transition-all", buttonBg, buttonText, `border-[${isDracula ? "#8be9fd" : "#2DA8FF"}]/60`, buttonHover)}
        >
          <span>▶</span> Projects
        </button>
        <button
          className={cn("rounded-sm border bg-transparent px-4 py-2 font-mono text-[12px] font-semibold transition-all", borderSecondary, textSecondary, buttonHoverBg, hoverBorderColor)}
        >
          <span style={{ marginRight: "6px" }}>ℹ</span> About Me
        </button>
        <button
          className={cn("rounded-sm border bg-transparent px-4 py-2 font-mono text-[12px] font-semibold transition-all", borderSecondary, textSecondary, buttonHoverBg, hoverBorderColor)}
        >
          <span style={{ marginRight: "6px" }}>✉</span> Contact
        </button>
      </div>

      {/* Stats grid */}
      <div
        className={cn("mb-12 grid grid-cols-4 gap-4 border-t border-b py-8", borderColor)}
        style={{
          background: isDracula
            ? "linear-gradient(135deg, rgba(139, 233, 253, 0.02) 0%, rgba(80, 250, 123, 0.02) 100%)"
            : "linear-gradient(135deg, rgba(45, 168, 255, 0.02) 0%, rgba(73, 208, 195, 0.02) 100%)",
        }}
      >
        {stats.map((stat, idx) => (
          <div key={idx} className="text-center">
            <p className={cn("font-serif text-[32px] font-bold mb-1", accentBlue)} style={{ letterSpacing: "-0.02em" }}>
              {stat.value}
            </p>
            <p className={cn("font-mono text-[10px] tracking-wide", textTertiary)}>{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Social links */}
      <div className="flex gap-3">
        {socialLinks.map((link) => {
          const Icon = link.icon
          return (
            <a
              key={link.label}
              href={link.href}
              title={link.label}
              className={cn("rounded-sm border p-2.5 transition-all", surfaceColor, borderColor, textTertiary, hoverBgColor, `hover:text-[${isDracula ? "#8be9fd" : "#2DA8FF"}]`, hoverBorderColor)}
            >
              <Icon size={16} />
            </a>
          )
        })}
      </div>
    </div>
  )
}
