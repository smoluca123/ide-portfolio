"use client"

import { useTheme } from "./theme-context"
import { cn } from "@/lib/utils"

interface Experience {
  period: string
  title: string
  company: string
  description: string
  techStack: string[]
}

const experiences: Experience[] = [
  {
    period: "2025 - Present",
    title: "Junior Software Developer",
    company: "EduVanceAI",
    description:
      "Building intelligent backend systems and AI integrations for an EdTech platform. ML-powered personalization, RAG pipelines, and scalable APIs serving thousands of learners daily.",
    techStack: ["FastAPI", "Python", "Django", "PostgreSQL", "Docker", "AWS", "GenAI", "React"],
  },
  {
    period: "Jun 2023 – Aug 2023",
    title: "User Experience Designer",
    company: "Zepto Digital Labs",
    description:
      "Designed UI for a simulation platform and improved user experience through design thinking principles. Delivered research-backed interface improvements that enhanced usability.",
    techStack: ["Figma", "UX Research", "Design Thinking", "Prototyping"],
  },
  {
    period: "Jun 2023 – Jul 2023",
    title: "Back End Intern",
    company: "Laser Technologies Pvt Ltd",
    description:
      "Managed and maintained backend systems and databases to support enterprise-level web applications. Ensured uptime, performance, and data integrity across production systems.",
    techStack: ["Backend", "Databases", "SQL", "Web Applications"],
  },
]

export function ExperienceContent() {
  const { theme } = useTheme()
  const isDracula = theme === "dracula"

  const bgColor = isDracula ? "bg-[#282a36]" : "bg-[#1E1E1E]"
  const commentColor = isDracula ? "text-[#6272a4]/80" : "text-[#49D0C3]/80"
  const textColor = isDracula ? "text-[#f8f8f2]" : "text-white"
  const textSecondary = isDracula ? "text-[#6272a4]" : "text-[#CCCCCC]/60"
  const textMuted = isDracula ? "text-[#6272a4]/50" : "text-[#CCCCCC]/70"
  const borderColor = isDracula ? "bg-[#44475a]" : "bg-[#374151]"
  const dotColor = isDracula ? "border-[#8be9fd]" : "border-[#2DA8FF]"
  const accentColor = isDracula ? "text-[#8be9fd]" : "text-[#2DA8FF]"
  const accentMuted = isDracula ? "text-[#6272a4]" : "text-[#CCCCCC]/50"
  const accentBg = isDracula ? "border-[#8be9fd]/40 bg-[#8be9fd]/10 text-[#8be9fd]" : "border-[#2DA8FF]/40 bg-[#2DA8FF]/10 text-[#2DA8FF]"

  return (
    <div className={cn("flex-1 overflow-y-auto px-10 py-8", bgColor)}>
      {/* Code comment */}
      <p className={cn("mb-5 font-mono text-[13px] italic", commentColor)}>
        {"// experience.ts - professional journey"}
      </p>

      {/* Hero headline — Syne display */}
      <h1
        className={cn("mb-3 font-serif text-[52px] font-extrabold leading-none tracking-tight", textColor)}
        style={{ letterSpacing: "-0.02em" }}
      >
        Experience
      </h1>

      {/* TypeScript interface stub */}
      <p className="mb-10 font-mono text-[13px]">
        <span className={isDracula ? "text-[#8be9fd]" : "text-[#5EC8FF]"}>interface</span>{" "}
        <span className={accentColor}>Career</span>{" "}
        <span className={isDracula ? "text-[#8be9fd]" : "text-[#5EC8FF]"}>extends</span>{" "}
        <span className={accentColor}>Timeline</span>{" "}
        <span className={isDracula ? "text-[#f8f8f2]/60" : "text-white/60"}>{"{}"}</span>
      </p>

      {/* Timeline */}
      <div className="relative">
        {/* Vertical track */}
        <div className={cn("absolute left-[7px] bottom-0 top-2 w-px", borderColor)} />

        <div className="flex flex-col gap-12">
          {experiences.map((exp, idx) => (
            <div key={idx} className="relative pl-10">
              {/* Dot */}
              <div className={cn("absolute left-0 top-[3px] h-4 w-4 rounded-full border-2", dotColor, bgColor)} />

              {/* Period */}
              <p className={cn("mb-1.5 font-mono text-[12px]", textSecondary)}>
                {exp.period}
              </p>

              {/* Role title — Syne bold */}
              <h2 className={cn("mb-1 font-serif text-[22px] font-bold leading-snug", textColor)}>
                {exp.title}
              </h2>

              {/* Company */}
              <p className="mb-3 font-mono text-[13px]">
                <span className={accentMuted}>@ </span>
                <span className={accentColor}>{exp.company}</span>
              </p>

              {/* Description */}
              <p className={cn("mb-4 max-w-2xl font-mono text-[13px] leading-relaxed", textMuted)}>
                {exp.description}
              </p>

              {/* Tech stack chips */}
              <div className="flex flex-wrap gap-2">
                {exp.techStack.map((tech) => (
                  <span
                    key={tech}
                    className={cn("rounded-sm border px-2.5 py-[3px] font-mono text-[11px] font-medium", accentBg)}
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
