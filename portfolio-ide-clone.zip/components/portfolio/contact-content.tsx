"use client"

import { useTheme } from "./theme-context"
import { Mail, Linkedin, MessageCircle, Github, Send, CheckCircle } from "lucide-react"
import { useState } from "react"

export function ContactContent() {
  const { theme } = useTheme()
  const isDracula = theme === "dracula"
  const [formData, setFormData] = useState({ name: "", email: "", message: "" })
  const [submitted, setSubmitted] = useState(false)

  const bgColor = isDracula ? "#282a36" : "#1E1E1E"
  const textColor = isDracula ? "#f8f8f2" : "#FFFFFF"
  const commentColor = isDracula ? "#6272a4" : "#49D0C3"
  const accentColor = isDracula ? "#8be9fd" : "#2DA8FF"
  const accentGreen = isDracula ? "#50fa7b" : "#49D0C3"
  const subtleColor = isDracula ? "#6272a4" : "#CCCCCC"
  const inputBg = isDracula ? "#44475a" : "#262626"

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => {
      setSubmitted(false)
      setFormData({ name: "", email: "", message: "" })
    }, 3000)
  }

  const contactMethods = [
    {
      icon: <Mail size={24} style={{ color: accentGreen }} />,
      label: "Email",
      value: "aahana.bobade@example.com",
      href: "mailto:aahana.bobade@example.com",
    },
    {
      icon: <MessageCircle size={24} style={{ color: accentColor }} />,
      label: "Telegram",
      value: "@aahana_bobade",
      href: "https://t.me/aahana_bobade",
    },
    {
      icon: <Github size={24} style={{ color: "#ff79c6" }} />,
      label: "GitHub",
      value: "github.com/aahana",
      href: "https://github.com/aahana",
    },
    {
      icon: <Linkedin size={24} style={{ color: "#ffb86c" }} />,
      label: "LinkedIn",
      value: "linkedin.com/in/aahana",
      href: "https://linkedin.com/in/aahana",
    },
  ]

  return (
    <div className="h-full overflow-y-auto p-6 font-mono" style={{ backgroundColor: bgColor, color: textColor }}>
      {/* Comment header */}
      <div className="mb-8 text-sm" style={{ color: commentColor }}>
        <div>// contact.css - Let&apos;s connect & collaborate</div>
        <div>// Always open to interesting projects and discussions</div>
      </div>

      <div className="grid gap-8 md:grid-cols-2">
        {/* Contact Form */}
        <section>
          <h2 className="mb-4 text-xl font-bold" style={{ color: accentColor }}>
            Send me a Message
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold mb-2" style={{ color: subtleColor }}>
                Name
              </label>
              <input
                type="text"
                placeholder="Your name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full rounded px-3 py-2 text-sm font-mono focus:outline-none transition-colors"
                style={{
                  backgroundColor: inputBg,
                  color: textColor,
                  border: `1px solid ${subtleColor}40`,
                }}
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-2" style={{ color: subtleColor }}>
                Email
              </label>
              <input
                type="email"
                placeholder="your.email@example.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full rounded px-3 py-2 text-sm font-mono focus:outline-none transition-colors"
                style={{
                  backgroundColor: inputBg,
                  color: textColor,
                  border: `1px solid ${subtleColor}40`,
                }}
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-2" style={{ color: subtleColor }}>
                Message
              </label>
              <textarea
                placeholder="Your message here..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                rows={5}
                className="w-full rounded px-3 py-2 text-sm font-mono focus:outline-none transition-colors resize-none"
                style={{
                  backgroundColor: inputBg,
                  color: textColor,
                  border: `1px solid ${subtleColor}40`,
                }}
                required
              />
            </div>

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 rounded px-4 py-2 text-sm font-semibold transition-opacity hover:opacity-75"
              style={{
                backgroundColor: accentColor,
                color: bgColor,
              }}
            >
              {submitted ? (
                <>
                  <CheckCircle size={16} />
                  <span>Message Sent!</span>
                </>
              ) : (
                <>
                  <Send size={16} />
                  <span>Send Message</span>
                </>
              )}
            </button>
          </form>
        </section>

        {/* Contact Methods */}
        <section>
          <h2 className="mb-4 text-xl font-bold" style={{ color: accentColor }}>
            Other Ways to Connect
          </h2>
          <div className="space-y-3">
            {contactMethods.map((method) => (
              <a
                key={method.label}
                href={method.href}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 rounded-lg p-4 transition-all hover:opacity-75"
                style={{
                  backgroundColor: "#262626" + "40",
                  border: `1px solid ${subtleColor}40`,
                }}
              >
                <div className="flex-shrink-0">{method.icon}</div>
                <div>
                  <div className="text-sm font-semibold" style={{ color: textColor }}>
                    {method.label}
                  </div>
                  <div className="text-xs" style={{ color: subtleColor }}>
                    {method.value}
                  </div>
                </div>
              </a>
            ))}
          </div>

          {/* Response time */}
          <div
            className="mt-6 rounded-lg p-4 text-sm"
            style={{
              backgroundColor: accentGreen + "15",
              border: `1px solid ${accentGreen}40`,
              color: accentGreen,
            }}
          >
            <div className="font-semibold mb-1">Response Time</div>
            <div>I typically respond within 24 hours</div>
          </div>
        </section>
      </div>
    </div>
  )
}
