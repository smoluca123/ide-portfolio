"use client"

import { ChevronDown, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"
import { useState } from "react"
import { useTheme } from "./theme-context"

export interface FileEntry {
  name: string
  ext: "tsx" | "html" | "js" | "json" | "ts" | "css" | "md" | "pdf"
}

interface FileExplorerProps {
  activeFile: string
  onFileSelect: (file: string) => void
}

const files: FileEntry[] = [
  { name: "home.tsx",          ext: "tsx"  },
  { name: "about.html",        ext: "html" },
  { name: "projects.js",       ext: "js"   },
  { name: "skills.json",       ext: "json" },
  { name: "experience.ts",     ext: "ts"   },
  { name: "contact.css",       ext: "css"  },
  { name: "README.md",         ext: "md"   },
  { name: "Aahana_Resume.pdf", ext: "pdf"  },
]

const EXT_COLOR: Record<FileEntry["ext"], string> = {
  tsx:  "#5EC8FF",
  ts:   "#2DA8FF",
  js:   "#F7DF1E",
  json: "#FFBD2E",
  html: "#F97316",
  css:  "#FF61D8",
  md:   "#CCCCCC",
  pdf:  "#FF5A5F",
}

const EXT_LABEL: Record<FileEntry["ext"], string> = {
  tsx:  "TSX",
  ts:   "TS",
  js:   "JS",
  json: "{}",
  html: "HTM",
  css:  "CSS",
  md:   "MD",
  pdf:  "PDF",
}

function FileIcon({ ext }: { ext: FileEntry["ext"] }) {
  const color = EXT_COLOR[ext]
  return (
    <span
      className="flex h-4 w-[26px] shrink-0 items-center justify-center rounded-sm font-mono text-[8px] font-bold"
      style={{
        color,
        border: `1px solid ${color}33`,
        background: `${color}11`,
      }}
    >
      {EXT_LABEL[ext]}
    </span>
  )
}

export function FileExplorer({ activeFile, onFileSelect }: FileExplorerProps) {
  const [open, setOpen] = useState(true)
  const { theme } = useTheme()

  const themeColors = {
    bg: theme === "dracula" ? "#282a36" : "#1A1A1A",
    border: theme === "dracula" ? "#44475a" : "#374151",
    text: theme === "dracula" ? "#f8f8f2" : "#CCCCCC",
    textMuted: theme === "dracula" ? "#6272a4" : "#CCCCCC/50",
    activeBg: theme === "dracula" ? "#44475a" : "#262626",
    hoverBg: theme === "dracula" ? "#44475a60" : "#262626/60",
    activeIndicator: theme === "dracula" ? "#50fa7b" : "#49D0C3",
    accentPink: theme === "dracula" ? "#ff79c6" : "#FF61D8",
    accentCyan: theme === "dracula" ? "#8be9fd" : "#49D0C3",
    surface: theme === "dracula" ? "#3f4148" : "#262626",
    surfaceBorder: theme === "dracula" ? "#44475a" : "#374151",
  }

  return (
    <div
      className="flex h-full w-56 shrink-0 flex-col border-r"
      style={{ 
        background: themeColors.bg,
        borderColor: themeColors.border,
      }}
    >
      {/* Section label */}
      <div className="px-4 pb-1 pt-3">
        <span 
          className="font-mono text-[10px] uppercase tracking-[0.12em]"
          style={{ color: themeColors.textMuted }}
        >
          Portfolio
        </span>
      </div>

      {/* Folder toggle */}
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center gap-1.5 px-3 py-1 text-left transition-colors"
        style={{ color: themeColors.text }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = `${themeColors.activeBg}40`
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = "transparent"
        }}
      >
        {open
          ? <ChevronDown className="h-3.5 w-3.5 shrink-0" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0" />
        }
        <span className="font-mono text-[12px]">aahana-bobade</span>
      </button>

      {/* Files */}
      {open && (
        <div className="flex flex-col pl-2">
          {files.map((file) => {
            const isActive = activeFile === file.name
            return (
              <button
                key={file.name}
                onClick={() => onFileSelect(file.name)}
                className={cn(
                  "flex w-full items-center gap-2 rounded-sm px-3 py-[5px] text-left font-mono text-[12px] transition-colors"
                )}
                style={{
                  backgroundColor: isActive ? themeColors.activeBg : "transparent",
                  color: isActive ? themeColors.text : themeColors.text,
                }}
                onMouseEnter={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.backgroundColor = themeColors.hoverBg
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.backgroundColor = "transparent"
                  }
                }}
              >
                <FileIcon ext={file.ext} />
                <span className="truncate">{file.name}</span>
                {isActive && (
                  <span 
                    className="ml-auto h-1.5 w-1.5 shrink-0 rounded-full"
                    style={{ backgroundColor: themeColors.activeIndicator }}
                  />
                )}
              </button>
            )
          })}
        </div>
      )}

      {/* Copilot badge at bottom */}
      <div className="mt-auto p-3">
        <div 
          className="flex items-center gap-2 rounded-sm border px-3 py-2"
          style={{ 
            borderColor: themeColors.surfaceBorder,
            backgroundColor: themeColors.surface,
          }}
        >
          <span 
            className="font-mono text-[10px]"
            style={{ color: themeColors.accentPink }}
          >
            ✦ Aahana&apos;s
          </span>
          <span 
            className="font-mono text-[10px]"
            style={{ color: themeColors.text }}
          >
            Copilot
          </span>
          <span 
            className="ml-auto rounded-sm border px-1 font-mono text-[9px]"
            style={{ 
              borderColor: `${themeColors.accentCyan}80`,
              color: themeColors.accentCyan,
            }}
          >
            open
          </span>
        </div>
      </div>
    </div>
  )
}
